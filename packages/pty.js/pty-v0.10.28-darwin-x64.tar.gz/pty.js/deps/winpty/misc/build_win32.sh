#!/bin/bash
g++ Win32Echo1.cc -o Win32Echo1
g++ Win32Echo2.cc -o Win32Echo2
g++ Win32Write1.cc -o Win32Write1
