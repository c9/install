localPty = require("./index.js");
pty = localPty;

function create() {
var pty = localPty.fork("C:\\Windows\\System32\\cmd.exe", [], {
    name: 'cmd',
    cols: 80,
    rows: 30,
    cwd: process.env.HOME || "c:\\",
    env: process.env
});
console.log(pty.pid)
console.log(pty.systemPID)

pty.on("data", function(data){
    process.stdout.write(">>>" + data)
})

process.stdin.on("data", function(data){
    pty.write(data)    
})
return pty;
}
ptys = [create(),
create(),
create(),
create()]


process.stdin.on("data", function(data){
    ptys.pop().destroy()
})

//console.log()